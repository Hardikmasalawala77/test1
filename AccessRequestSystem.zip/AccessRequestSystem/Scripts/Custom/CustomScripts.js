﻿$(document).ready(function () {
    $(window).on('resize', function () {
        $(".DynamicClasss").removeClass('mycontent-left', $(window).width() < 996);
        $(".DynamicClasss").addClass('mycontent-left', $(window).width() > 996);
        if ($(window).width() < 1183) {
            if ($(window).width() < 975) {
                $('.body-content').css("margin-top", "100px");
            }
            else {
                $('.body-content').css("margin-top", "50px");
            }
            if ($(window).width() < 751) {
                $('.body-content').css("margin-top", "0px");
            }
        }
        else {
            $('.body-content').css("margin-top", "0px");
        }
    });
})

$(document).ready(function () {
    $('.buttons-excel').css("margin-left", "10px");
    $('.dt-buttons').css("float", "Right");
    $(".DynamicClasss").removeClass('mycontent-left', $(window).width() < 996);

    $(".DynamicClasss").addClass('mycontent-left', $(window).width() > 996);

    if ($(window).width() < 1183) {
        if ($(window).width() < 975) {
            $('.body-content').css("margin-top", "100px");
        }
        else {
            $('.body-content').css("margin-top", "50px");
        }
        if ($(window).width() < 751) {
            $('.body-content').css("margin-top", "0px");
        }
    }
    else {
        $('.body-content').css("margin-top", "0px");
    }
});

$(document).ready(function () {
    $('.jsSelect2').select2();
    $(document)
      .ajaxStart(function () {
          debugger;
          //ajax request went so show the loading image
          $('.Mloader').show()
      })
    .ajaxStop(function () {
        debugger;
        //got response so hide the loading image
        $('.Mloader').hide();
    });
    $("form").on("submit", function () {
        $('.Mloader').show()
    });
    //$("form").error(function () {
    //    $('.Mloader').hide()
    //});
});
function setAutoComplete(ControlSelector, URL, searchValue) {
    $(ControlSelector).autocomplete({
        source: function (request, response) {
            $.ajax({
                //url: '/' + ControllerName + '/' + ActionName + '/',
                url: URL,
                data: { searchVal: searchValue },
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    response($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (response) {
                    alert(response.responseText);
                },
                failure: function (response) {
                    alert(response.responseText);
                }
            });
        },
        select: function (e, i) {
            //$("#hfCustomer").val(i.item.val);
            onSelectEvent(i.item.val);
        },
        minLength: 1
    });
}
function imgError(image) {
    image.onerror = "";
    image.src = "/SafetyInspectionSystem/Content/images/LTlogo1.png";
    return true;
}

function NoInitimg(image) {
    image.onerror = "";
    image.src = "/SafetyInspectionSystem/Content/images/LTlogo1.jpg"
    return true;
}
function test1() {
    console.log("test1");
}