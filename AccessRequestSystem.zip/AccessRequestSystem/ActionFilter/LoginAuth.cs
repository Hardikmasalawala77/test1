﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace AccessRequestSystem
{
    public class LoginAuth: ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string UserID = (string)filterContext.HttpContext.Session.Contents["txtPsno"];
            string actionName = filterContext.ActionDescriptor.ActionName;
            string controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;

            if (String.IsNullOrEmpty(UserID))
            {

                HttpContext ctx = System.Web.HttpContext.Current;
              
                filterContext.HttpContext.Session.Contents["rpath"] = ctx.Request.Url.AbsolutePath;
                RouteValueDictionary redirectTargetDictionary = new RouteValueDictionary();
                redirectTargetDictionary.Add("action", "NoAccess");
                redirectTargetDictionary.Add("controller", "Home");
                filterContext.Result = new RedirectToRouteResult(redirectTargetDictionary);

                filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
                filterContext.HttpContext.Response.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
            }
            base.OnActionExecuting(filterContext);
        }


    }
}