﻿using AccessRequestSystem.AD;
using AccessRequestSystem.Common;
using AccessRequestSystem.Models;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace AccessRequestSystem.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult NoAccess()
        {
            return View();
        }

        [LoginAuth]
        public ActionResult Index()
        {
            //Assembly asm = Assembly.GetAssembly(typeof(MyWebDll.MvcApplication));
            //Assembly asm = Assembly.GetExecutingAssembly();

            //var controlleractionlist = asm.GetTypes()
            //        .Where(type => typeof(System.Web.Mvc.Controller).IsAssignableFrom(type))
            //        .SelectMany(type => type.GetMethods(BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.Public))
            //        .Where(m => !m.GetCustomAttributes(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute), true).Any())
            //        .Select(x => new { Controller = x.DeclaringType.Name, Action = x.Name, ReturnType = x.ReturnType.Name, Attributes = String.Join(",", x.GetCustomAttributes().Select(a => a.GetType().Name.Replace("Attribute", ""))) })
            //        .OrderBy(x => x.Controller).ThenBy(x => x.Action).ToList();
            return View();
        }
        [LoginAuth]
        public ActionResult ContactUs()
        {
            return View();
        }
        #region FetchAllVIew
        [HttpPost]
        public JsonResult FetchAllView( string keyword) {
            Status objStatus = new Status();
            try
            {
                
                var projectName = Assembly.GetExecutingAssembly().FullName.Split(',')[0];
                Assembly asm = Assembly.GetAssembly(typeof(MvcApplication));
                var model = asm.GetTypes().
                    SelectMany(t => t.GetMethods(BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.Public))
                    .Where(d => d.ReturnType.Name == "ActionResult").Select(n => new ListMenuModel()
                    {
                        Controller = n.DeclaringType?.Name.Replace("Controller", ""),
                        Action = n.Name,
                        ReturnType = n.ReturnType.Name,
                        Attributes = string.Join(",", n.GetCustomAttributes().Select(a => a.GetType().Name.Replace("Attribute", ""))),
                        Area = n.DeclaringType.Namespace.ToString().Replace(projectName + ".", "").Replace("Areas.", "").Replace(".Controllers", "").Replace("Controllers", "")
                    });
                objStatus.Data = model.Where(x => x.Attributes == "LoginAuth");
                objStatus.IsSuccess= true;
                return Json(objStatus, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                objStatus.Data = null;
                objStatus.Message= ex.StackTrace;
                objStatus.IsSuccess = false;
                return Json(objStatus, JsonRequestBehavior.AllowGet);
                
            }
        }
        #endregion
        #region Datatables
        [LoginAuth]
        public ActionResult Datatables()
        {
            return View();
        }

      
        #endregion

        #region Login
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string txtPsno, string txtPassword, string ReturnUrl)
        {
            DirectoryService ds = new DirectoryService();
            bool authen = ds.getAuthentication(txtPsno, txtPassword);
            try
            {
                if (authen)
                {
                    Session["txtPsno"] = txtPsno;
                    HttpCookie hc = new HttpCookie("Psno");
                    hc.Value = txtPsno;
                    hc.Expires = DateTime.Now.AddYears(20);
                    Response.Cookies.Add(hc);
                    ViewBag.Message = String.Empty;
                    if (!string.IsNullOrEmpty(ReturnUrl))
                    {
                        return RedirectToLocal(ReturnUrl);
                    }
                    return RedirectToAction("Index", "Home");
                }

                else
                {
                    ViewBag.Message = "Username or password is invalid";
                    return View();
                }
            }
            catch (Exception e)
            {

                throw e;
            }

        }

        #endregion


       

        #region Utility
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }
        #endregion
    }
}