﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AccessRequestSystem
{
    public struct Status
    {

        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public Object Data { get; set; }
        
    }
}