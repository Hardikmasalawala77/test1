﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AccessRequestSystem
{
    public class MenuList
    {
        /// <summary>
        /// Menu ID
        /// </summary>
        public int M_ID { get; set; }
        /// <summary>
        /// Menu Parent ID 
        /// </summary>
        public int? M_P_ID { get; set; }
        /// <summary>
        /// Menu Display Text
        /// </summary>
        public string M_NAME { get; set; }
        /// <summary>
        /// Menu CONTROLLER Name
        /// </summary>
        public string CONTROLLER_NAME { get; set; }
        /// <summary>
        /// Menu ACTION Name
        /// </summary>
        public string ACTION_NAME { get; set; }
        /// <summary>
        /// Menu ICON from FONT AWESOME
        /// </summary>
        public string M_ICON{ get; set; }
        public bool IsRootNode { get; set; } = false;
        public bool HasChildNode { get; set; } = false;
    }
}