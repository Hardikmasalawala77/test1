﻿using System.Web.Optimization;

namespace AccessRequestSystem
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css",
                      "~/Content/bootstrap-grid.css"
                      ));

            bundles.Add(new StyleBundle("~/Style").Include(
                       "~/Content/Style.css",
                       "~/Content/fontawesome/css/all.css"
                      ));
            bundles.Add(new ScriptBundle("~/CustomScripts").Include(
                      "~/Scripts/Custom/CustomScripts.js"));
            //#region timeoutDialog CSS/JS
            //bundles.Add(new StyleBundle("~/TimeoutCss").Include(
            //           "~/timeout/timeout-dialog.css"
            //          ));
            //bundles.Add(new ScriptBundle("~/TimeoutScripts").Include(
            //          "~/Scripts/timeout/timeout-dialog.js"));
            //#endregion

            #region Datatables CSS/JS
            bundles.Add(new StyleBundle("~/DatatablesCss").Include(
                       "~/Content/Datatables/dataTables.bootstrap4.min.css"
                      ));
            bundles.Add(new ScriptBundle("~/DatatablesScripts").Include(
                      "~/Scripts/Datatables/jquery-3.3.1.js",
                      "~/Scripts/Datatables/jquery.dataTables.min.js",
                      "~/Scripts/Datatables/dataTables.bootstrap4.min.js",
                      "~/Scripts/Datatables/dataTables.responsive.min.js",
                      "~/Scripts/Datatables/responsive.bootstrap4.min.js"));
            #endregion

            #region Select2 CSS/JS
            bundles.Add(new StyleBundle("~/Select2Css").Include(
                       "~/Content/Select2/select2.min.css"
                      ));
            bundles.Add(new ScriptBundle("~/Select2Scripts").Include(
                      "~/Scripts/Select2/select2.min.js"));
            #endregion
            #region Select2 CSS/JS
            bundles.Add(new StyleBundle("~/toastCss").Include(
                       "~/Content/toast/jquery.toast.css"
                      ));
            bundles.Add(new ScriptBundle("~/toastScripts").Include(
                      "~/Scripts/toast/jquery.toast.js"));
            #endregion
        }
    }
}
