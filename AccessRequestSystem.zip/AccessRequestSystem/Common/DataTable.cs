﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AccessRequestSystem.Common
{
    //public class DataTable
    //{
    //    public List<Object> data { get; set; }
    //}
}