﻿using System.Collections.Generic;

namespace AccessRequestSystem
{
    public class MenuConfig
    {
        MenuList objMenu = new MenuList();

        public List<MenuList> InitMenu()
        {
            List<MenuList> objMenuList = new List<MenuList>();
            //Root Nodes START 
            objMenuList.Add(AddMenuItem(1, true, false, 0, "Index", "Home", "Home", "fa-home"));
            objMenuList.Add(AddMenuItem(2, true, true, 0, string.Empty, string.Empty, "Master Session", "fa-list"));
            objMenuList.Add(AddMenuItem(3, true, true, 0, string.Empty, string.Empty, "Bootstrap 4 Componenet", "fa-list"));
            //Root Nodes END 
            //Child Nodes START 
            objMenuList.Add(AddMenuItem(3, false, false, 3, "Datatables", "Home", "Datatable", string.Empty));
            objMenuList.Add(AddMenuItem(3, false, false, 2, "Area", "GasCylinderRequirement", "Maintain Area", string.Empty));
            objMenuList.Add(AddMenuItem(4, false, false, 2, "Cylinder", "GasCylinderRequirement", "Maintain Cylinder", string.Empty));
            objMenuList.Add(AddMenuItem(5, false, false, 2, "Gas", "GasCylinderRequirement", "Maintain Gas", string.Empty));
            objMenuList.Add(AddMenuItem(6, false, false, 2, "Supplier", "GasCylinderRequirement", "Maintain Supplier", string.Empty));
            objMenuList.Add(AddMenuItem(7, false, false, 2, "Role", "GasCylinderRequirement", "Assign Role", string.Empty));
            ////Child Nodes END 
            return objMenuList;
        }
        public MenuList AddMenuItem(int MenuId, bool IsRootNode, bool HasChildNode, int MenuParentID, string ActionName, string ControllerName, string MenuText, string MenuIcon)
        {
            var objMenuList = new MenuList
            {
                M_ID = MenuId,
                IsRootNode = IsRootNode,
                HasChildNode = HasChildNode,
                M_P_ID = MenuParentID,
                ACTION_NAME = ActionName,
                CONTROLLER_NAME = ControllerName,
                M_NAME = MenuText,
                M_ICON = "fas " + MenuIcon
            };
            return objMenuList;
        }

    }
}